if (setSeason == 0) {
    loader.load("models/m_house1_seasonSpring.json", function ( house ) {
        // Number of models placed for each type is decided by user
        for (i = 0; i < setHouse1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            // Places models within the area of the terrain
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            // Increases size of model to a better visible value
            houses[i].scale.set(10,10,10);
            // Adds model to scene
            group.add( houses[i] );
        }
    });
    loader.load("models/m_house2_seasonSpring.json", function ( house ) {
        for (i = 0; i < setHouse2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            group.add( houses[i] );
        }
    });
    loader.load("models/m_tree1_seasonSpring.json", function ( house ) {
        for (i = 0; i < setTree1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            group.add( houses[i] );
        }
    });
    loader.load("models/m_tree2_seasonSpring.json", function ( house ) {
        for (i = 0; i < setTree2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            group.add( houses[i] );
        }
    });
}
if (setSeason == 1) {
    loader.load("models/m_house1_seasonSummer.json", function ( house ) {
        for (i = 0; i < setHouse1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_house2_seasonSummer.json", function ( house ) {
        for (i = 0; i < setHouse2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree1_seasonSummer.json", function ( house ) {
        for (i = 0; i < setTree1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree2_seasonSummer.json", function ( house ) {
        for (i = 0; i < setTree2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
}
if (setSeason == 2) {
    loader.load("models/m_house1_seasonFall.json", function ( house ) {
        for (i = 0; i < setHouse1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_house2_seasonFall.json", function ( house ) {
        for (i = 0; i < setHouse2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree1_seasonFall.json", function ( house ) {
        for (i = 0; i < setTree1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree2_seasonFall.json", function ( house ) {
        for (i = 0; i < setTree2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
}
if (setSeason == 3) {
    loader.load("models/m_house1_seasonWinter.json", function ( house ) {
        for (i = 0; i < setHouse1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_house2_seasonWinter.json", function ( house ) {
        for (i = 0; i < setHouse2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree1_seasonWinter.json", function ( house ) {
        for (i = 0; i < setTree1Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
    loader.load("models/m_tree2_seasonWinter.json", function ( house ) {
        for (i = 0; i < setTree2Num; i++) {
            houses[i] = house.clone();
            houses[i].castShadow = true;
            houses[i].position.x = getRandomInt(-(setSizeX/2 - edgeBuffer),(setSizeX/2 - edgeBuffer));
            houses[i].position.z = getRandomInt(-(setSizeY/2 - edgeBuffer),(setSizeY/2 - edgeBuffer));
            // raycaster.set(houses[i].position, new THREE.Vector3(0, -1, 0));
            // var intersects = raycaster.intersectObject(terrainScene);
            houses[i].position.y =50;
            houses[i].scale.set(10,10,10);
            scene.add( houses[i] );
        }
    });
}
